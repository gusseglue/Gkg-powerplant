# LB Tablet - App Templates

This repository contains templates for [LB Tablet](https://lbscripts.com/tablet) apps, showcasing most functions provided by LB Tablet.

## Templates

-   [Vanilla JS app template](./lb-tablet-vanillajs)
-   [React JS app template](./lb-tablet-reactjs)
-   [React TS app template](./lb-tablet-reactts)
