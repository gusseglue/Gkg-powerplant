Config = {}

Config.Identifier = "react-ts-template"
Config.DefaultApp = true

Config.Name = "React TS"
Config.Description = "Template app using React and TypeScript."
Config.Developer = "LB Scripts"
