fx_version "cerulean"
game "gta5"

title "LB Tablet - App Template | Vanilla JS"
description "A template for creating apps for the LB Tablet."
author "Breze & Loaf"

client_script "client.lua"

file "ui/**"
ui_page "ui/index.html"
